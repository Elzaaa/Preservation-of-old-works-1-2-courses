﻿namespace FootballСhampionship
{
	partial class Form1
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
            this.team0 = new System.Windows.Forms.Label();
            this.team1 = new System.Windows.Forms.Label();
            this.team2 = new System.Windows.Forms.Label();
            this.team3 = new System.Windows.Forms.Label();
            this.team4 = new System.Windows.Forms.Label();
            this.team5 = new System.Windows.Forms.Label();
            this.team6 = new System.Windows.Forms.Label();
            this.team7 = new System.Windows.Forms.Label();
            this.team8 = new System.Windows.Forms.Label();
            this.team12 = new System.Windows.Forms.Label();
            this.team9 = new System.Windows.Forms.Label();
            this.team13 = new System.Windows.Forms.Label();
            this.team10 = new System.Windows.Forms.Label();
            this.team14 = new System.Windows.Forms.Label();
            this.team11 = new System.Windows.Forms.Label();
            this.team15 = new System.Windows.Forms.Label();
            this.team32 = new System.Windows.Forms.Label();
            this.team33 = new System.Windows.Forms.Label();
            this.team34 = new System.Windows.Forms.Label();
            this.team35 = new System.Windows.Forms.Label();
            this.team36 = new System.Windows.Forms.Label();
            this.team37 = new System.Windows.Forms.Label();
            this.team38 = new System.Windows.Forms.Label();
            this.team39 = new System.Windows.Forms.Label();
            this.team48 = new System.Windows.Forms.Label();
            this.team49 = new System.Windows.Forms.Label();
            this.team50 = new System.Windows.Forms.Label();
            this.team51 = new System.Windows.Forms.Label();
            this.team56 = new System.Windows.Forms.Label();
            this.team57 = new System.Windows.Forms.Label();
            this.team60 = new System.Windows.Forms.Label();
            this.team61 = new System.Windows.Forms.Label();
            this.team58 = new System.Windows.Forms.Label();
            this.team59 = new System.Windows.Forms.Label();
            this.team52 = new System.Windows.Forms.Label();
            this.team54 = new System.Windows.Forms.Label();
            this.team53 = new System.Windows.Forms.Label();
            this.team55 = new System.Windows.Forms.Label();
            this.team40 = new System.Windows.Forms.Label();
            this.team42 = new System.Windows.Forms.Label();
            this.team44 = new System.Windows.Forms.Label();
            this.team46 = new System.Windows.Forms.Label();
            this.team41 = new System.Windows.Forms.Label();
            this.team43 = new System.Windows.Forms.Label();
            this.team45 = new System.Windows.Forms.Label();
            this.team47 = new System.Windows.Forms.Label();
            this.team16 = new System.Windows.Forms.Label();
            this.team24 = new System.Windows.Forms.Label();
            this.team20 = new System.Windows.Forms.Label();
            this.team28 = new System.Windows.Forms.Label();
            this.team17 = new System.Windows.Forms.Label();
            this.team25 = new System.Windows.Forms.Label();
            this.team21 = new System.Windows.Forms.Label();
            this.team29 = new System.Windows.Forms.Label();
            this.team18 = new System.Windows.Forms.Label();
            this.team26 = new System.Windows.Forms.Label();
            this.team22 = new System.Windows.Forms.Label();
            this.team30 = new System.Windows.Forms.Label();
            this.team19 = new System.Windows.Forms.Label();
            this.team27 = new System.Windows.Forms.Label();
            this.team23 = new System.Windows.Forms.Label();
            this.team31 = new System.Windows.Forms.Label();
            this.playButton = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // team0
            // 
            this.team0.BackColor = System.Drawing.Color.Transparent;
            this.team0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team0.Location = new System.Drawing.Point(12, 33);
            this.team0.Name = "team0";
            this.team0.Size = new System.Drawing.Size(137, 22);
            this.team0.TabIndex = 0;
            this.team0.Text = "team";
            // 
            // team1
            // 
            this.team1.BackColor = System.Drawing.Color.Transparent;
            this.team1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team1.Location = new System.Drawing.Point(12, 60);
            this.team1.Name = "team1";
            this.team1.Size = new System.Drawing.Size(137, 22);
            this.team1.TabIndex = 0;
            this.team1.Text = "team";
            // 
            // team2
            // 
            this.team2.BackColor = System.Drawing.Color.Transparent;
            this.team2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team2.Location = new System.Drawing.Point(12, 95);
            this.team2.Name = "team2";
            this.team2.Size = new System.Drawing.Size(137, 22);
            this.team2.TabIndex = 0;
            this.team2.Text = "team";
            // 
            // team3
            // 
            this.team3.BackColor = System.Drawing.Color.Transparent;
            this.team3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team3.Location = new System.Drawing.Point(12, 122);
            this.team3.Name = "team3";
            this.team3.Size = new System.Drawing.Size(137, 22);
            this.team3.TabIndex = 0;
            this.team3.Text = "team";
            // 
            // team4
            // 
            this.team4.BackColor = System.Drawing.Color.Transparent;
            this.team4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team4.Location = new System.Drawing.Point(12, 158);
            this.team4.Name = "team4";
            this.team4.Size = new System.Drawing.Size(137, 22);
            this.team4.TabIndex = 0;
            this.team4.Text = "team";
            // 
            // team5
            // 
            this.team5.BackColor = System.Drawing.Color.Transparent;
            this.team5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team5.Location = new System.Drawing.Point(12, 185);
            this.team5.Name = "team5";
            this.team5.Size = new System.Drawing.Size(137, 22);
            this.team5.TabIndex = 0;
            this.team5.Text = "team";
            // 
            // team6
            // 
            this.team6.BackColor = System.Drawing.Color.Transparent;
            this.team6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team6.Location = new System.Drawing.Point(12, 220);
            this.team6.Name = "team6";
            this.team6.Size = new System.Drawing.Size(137, 22);
            this.team6.TabIndex = 0;
            this.team6.Text = "team";
            // 
            // team7
            // 
            this.team7.BackColor = System.Drawing.Color.Transparent;
            this.team7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team7.Location = new System.Drawing.Point(12, 247);
            this.team7.Name = "team7";
            this.team7.Size = new System.Drawing.Size(137, 22);
            this.team7.TabIndex = 0;
            this.team7.Text = "team";
            // 
            // team8
            // 
            this.team8.BackColor = System.Drawing.Color.Transparent;
            this.team8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team8.Location = new System.Drawing.Point(12, 284);
            this.team8.Name = "team8";
            this.team8.Size = new System.Drawing.Size(137, 22);
            this.team8.TabIndex = 0;
            this.team8.Text = "team";
            // 
            // team12
            // 
            this.team12.BackColor = System.Drawing.Color.Transparent;
            this.team12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team12.Location = new System.Drawing.Point(12, 409);
            this.team12.Name = "team12";
            this.team12.Size = new System.Drawing.Size(137, 22);
            this.team12.TabIndex = 0;
            this.team12.Text = "team";
            // 
            // team9
            // 
            this.team9.BackColor = System.Drawing.Color.Transparent;
            this.team9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team9.Location = new System.Drawing.Point(12, 311);
            this.team9.Name = "team9";
            this.team9.Size = new System.Drawing.Size(137, 22);
            this.team9.TabIndex = 0;
            this.team9.Text = "team";
            // 
            // team13
            // 
            this.team13.BackColor = System.Drawing.Color.Transparent;
            this.team13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team13.Location = new System.Drawing.Point(12, 436);
            this.team13.Name = "team13";
            this.team13.Size = new System.Drawing.Size(137, 22);
            this.team13.TabIndex = 0;
            this.team13.Text = "team";
            // 
            // team10
            // 
            this.team10.BackColor = System.Drawing.Color.Transparent;
            this.team10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team10.Location = new System.Drawing.Point(12, 346);
            this.team10.Name = "team10";
            this.team10.Size = new System.Drawing.Size(137, 22);
            this.team10.TabIndex = 0;
            this.team10.Text = "team";
            // 
            // team14
            // 
            this.team14.BackColor = System.Drawing.Color.Transparent;
            this.team14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team14.Location = new System.Drawing.Point(12, 471);
            this.team14.Name = "team14";
            this.team14.Size = new System.Drawing.Size(137, 22);
            this.team14.TabIndex = 0;
            this.team14.Text = "team";
            // 
            // team11
            // 
            this.team11.BackColor = System.Drawing.Color.Transparent;
            this.team11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team11.Location = new System.Drawing.Point(12, 373);
            this.team11.Name = "team11";
            this.team11.Size = new System.Drawing.Size(137, 22);
            this.team11.TabIndex = 0;
            this.team11.Text = "team";
            // 
            // team15
            // 
            this.team15.BackColor = System.Drawing.Color.Transparent;
            this.team15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team15.Location = new System.Drawing.Point(12, 498);
            this.team15.Name = "team15";
            this.team15.Size = new System.Drawing.Size(137, 22);
            this.team15.TabIndex = 0;
            this.team15.Text = "team";
            // 
            // team32
            // 
            this.team32.BackColor = System.Drawing.Color.Transparent;
            this.team32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team32.Location = new System.Drawing.Point(155, 63);
            this.team32.Name = "team32";
            this.team32.Size = new System.Drawing.Size(137, 22);
            this.team32.TabIndex = 0;
            this.team32.Text = "team";
            // 
            // team33
            // 
            this.team33.BackColor = System.Drawing.Color.Transparent;
            this.team33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team33.Location = new System.Drawing.Point(155, 90);
            this.team33.Name = "team33";
            this.team33.Size = new System.Drawing.Size(137, 22);
            this.team33.TabIndex = 0;
            this.team33.Text = "team";
            // 
            // team34
            // 
            this.team34.BackColor = System.Drawing.Color.Transparent;
            this.team34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team34.Location = new System.Drawing.Point(155, 188);
            this.team34.Name = "team34";
            this.team34.Size = new System.Drawing.Size(137, 22);
            this.team34.TabIndex = 0;
            this.team34.Text = "team";
            // 
            // team35
            // 
            this.team35.BackColor = System.Drawing.Color.Transparent;
            this.team35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team35.Location = new System.Drawing.Point(155, 215);
            this.team35.Name = "team35";
            this.team35.Size = new System.Drawing.Size(137, 22);
            this.team35.TabIndex = 0;
            this.team35.Text = "team";
            // 
            // team36
            // 
            this.team36.BackColor = System.Drawing.Color.Transparent;
            this.team36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team36.Location = new System.Drawing.Point(155, 314);
            this.team36.Name = "team36";
            this.team36.Size = new System.Drawing.Size(137, 22);
            this.team36.TabIndex = 0;
            this.team36.Text = "team";
            // 
            // team37
            // 
            this.team37.BackColor = System.Drawing.Color.Transparent;
            this.team37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team37.Location = new System.Drawing.Point(155, 341);
            this.team37.Name = "team37";
            this.team37.Size = new System.Drawing.Size(137, 22);
            this.team37.TabIndex = 0;
            this.team37.Text = "team";
            // 
            // team38
            // 
            this.team38.BackColor = System.Drawing.Color.Transparent;
            this.team38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team38.Location = new System.Drawing.Point(155, 439);
            this.team38.Name = "team38";
            this.team38.Size = new System.Drawing.Size(137, 22);
            this.team38.TabIndex = 0;
            this.team38.Text = "team";
            // 
            // team39
            // 
            this.team39.BackColor = System.Drawing.Color.Transparent;
            this.team39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team39.Location = new System.Drawing.Point(155, 466);
            this.team39.Name = "team39";
            this.team39.Size = new System.Drawing.Size(137, 22);
            this.team39.TabIndex = 0;
            this.team39.Text = "team";
            // 
            // team48
            // 
            this.team48.BackColor = System.Drawing.Color.Transparent;
            this.team48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team48.Location = new System.Drawing.Point(299, 122);
            this.team48.Name = "team48";
            this.team48.Size = new System.Drawing.Size(137, 22);
            this.team48.TabIndex = 0;
            this.team48.Text = "team";
            // 
            // team49
            // 
            this.team49.BackColor = System.Drawing.Color.Transparent;
            this.team49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team49.Location = new System.Drawing.Point(299, 149);
            this.team49.Name = "team49";
            this.team49.Size = new System.Drawing.Size(137, 22);
            this.team49.TabIndex = 0;
            this.team49.Text = "team";
            // 
            // team50
            // 
            this.team50.BackColor = System.Drawing.Color.Transparent;
            this.team50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team50.Location = new System.Drawing.Point(299, 373);
            this.team50.Name = "team50";
            this.team50.Size = new System.Drawing.Size(137, 22);
            this.team50.TabIndex = 0;
            this.team50.Text = "team";
            // 
            // team51
            // 
            this.team51.BackColor = System.Drawing.Color.Transparent;
            this.team51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team51.Location = new System.Drawing.Point(299, 400);
            this.team51.Name = "team51";
            this.team51.Size = new System.Drawing.Size(137, 22);
            this.team51.TabIndex = 0;
            this.team51.Text = "team";
            // 
            // team56
            // 
            this.team56.BackColor = System.Drawing.Color.Transparent;
            this.team56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team56.Location = new System.Drawing.Point(442, 237);
            this.team56.Name = "team56";
            this.team56.Size = new System.Drawing.Size(137, 22);
            this.team56.TabIndex = 0;
            this.team56.Text = "team";
            // 
            // team57
            // 
            this.team57.BackColor = System.Drawing.Color.Transparent;
            this.team57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team57.Location = new System.Drawing.Point(442, 264);
            this.team57.Name = "team57";
            this.team57.Size = new System.Drawing.Size(137, 22);
            this.team57.TabIndex = 0;
            this.team57.Text = "team";
            // 
            // team60
            // 
            this.team60.BackColor = System.Drawing.Color.Transparent;
            this.team60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team60.Location = new System.Drawing.Point(603, 237);
            this.team60.Name = "team60";
            this.team60.Size = new System.Drawing.Size(137, 22);
            this.team60.TabIndex = 0;
            this.team60.Text = "team";
            // 
            // team61
            // 
            this.team61.BackColor = System.Drawing.Color.Transparent;
            this.team61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team61.Location = new System.Drawing.Point(603, 264);
            this.team61.Name = "team61";
            this.team61.Size = new System.Drawing.Size(137, 22);
            this.team61.TabIndex = 0;
            this.team61.Text = "team";
            // 
            // team58
            // 
            this.team58.BackColor = System.Drawing.Color.Transparent;
            this.team58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team58.Location = new System.Drawing.Point(765, 237);
            this.team58.Name = "team58";
            this.team58.Size = new System.Drawing.Size(137, 22);
            this.team58.TabIndex = 0;
            this.team58.Text = "team";
            // 
            // team59
            // 
            this.team59.BackColor = System.Drawing.Color.Transparent;
            this.team59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team59.Location = new System.Drawing.Point(765, 264);
            this.team59.Name = "team59";
            this.team59.Size = new System.Drawing.Size(137, 22);
            this.team59.TabIndex = 0;
            this.team59.Text = "team";
            // 
            // team52
            // 
            this.team52.BackColor = System.Drawing.Color.Transparent;
            this.team52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team52.Location = new System.Drawing.Point(910, 122);
            this.team52.Name = "team52";
            this.team52.Size = new System.Drawing.Size(137, 22);
            this.team52.TabIndex = 0;
            this.team52.Text = "team";
            // 
            // team54
            // 
            this.team54.BackColor = System.Drawing.Color.Transparent;
            this.team54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team54.Location = new System.Drawing.Point(910, 373);
            this.team54.Name = "team54";
            this.team54.Size = new System.Drawing.Size(137, 22);
            this.team54.TabIndex = 0;
            this.team54.Text = "team";
            // 
            // team53
            // 
            this.team53.BackColor = System.Drawing.Color.Transparent;
            this.team53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team53.Location = new System.Drawing.Point(910, 149);
            this.team53.Name = "team53";
            this.team53.Size = new System.Drawing.Size(137, 22);
            this.team53.TabIndex = 0;
            this.team53.Text = "team";
            // 
            // team55
            // 
            this.team55.BackColor = System.Drawing.Color.Transparent;
            this.team55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team55.Location = new System.Drawing.Point(910, 400);
            this.team55.Name = "team55";
            this.team55.Size = new System.Drawing.Size(137, 22);
            this.team55.TabIndex = 0;
            this.team55.Text = "team";
            // 
            // team40
            // 
            this.team40.BackColor = System.Drawing.Color.Transparent;
            this.team40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team40.Location = new System.Drawing.Point(1055, 63);
            this.team40.Name = "team40";
            this.team40.Size = new System.Drawing.Size(137, 22);
            this.team40.TabIndex = 0;
            this.team40.Text = "team";
            // 
            // team42
            // 
            this.team42.BackColor = System.Drawing.Color.Transparent;
            this.team42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team42.Location = new System.Drawing.Point(1055, 188);
            this.team42.Name = "team42";
            this.team42.Size = new System.Drawing.Size(137, 22);
            this.team42.TabIndex = 0;
            this.team42.Text = "team";
            // 
            // team44
            // 
            this.team44.BackColor = System.Drawing.Color.Transparent;
            this.team44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team44.Location = new System.Drawing.Point(1055, 314);
            this.team44.Name = "team44";
            this.team44.Size = new System.Drawing.Size(137, 22);
            this.team44.TabIndex = 0;
            this.team44.Text = "team";
            // 
            // team46
            // 
            this.team46.BackColor = System.Drawing.Color.Transparent;
            this.team46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team46.Location = new System.Drawing.Point(1055, 439);
            this.team46.Name = "team46";
            this.team46.Size = new System.Drawing.Size(137, 22);
            this.team46.TabIndex = 0;
            this.team46.Text = "team";
            // 
            // team41
            // 
            this.team41.BackColor = System.Drawing.Color.Transparent;
            this.team41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team41.Location = new System.Drawing.Point(1055, 90);
            this.team41.Name = "team41";
            this.team41.Size = new System.Drawing.Size(137, 22);
            this.team41.TabIndex = 0;
            this.team41.Text = "team";
            // 
            // team43
            // 
            this.team43.BackColor = System.Drawing.Color.Transparent;
            this.team43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team43.Location = new System.Drawing.Point(1055, 215);
            this.team43.Name = "team43";
            this.team43.Size = new System.Drawing.Size(137, 22);
            this.team43.TabIndex = 0;
            this.team43.Text = "team";
            // 
            // team45
            // 
            this.team45.BackColor = System.Drawing.Color.Transparent;
            this.team45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team45.Location = new System.Drawing.Point(1055, 341);
            this.team45.Name = "team45";
            this.team45.Size = new System.Drawing.Size(137, 22);
            this.team45.TabIndex = 0;
            this.team45.Text = "team";
            // 
            // team47
            // 
            this.team47.BackColor = System.Drawing.Color.Transparent;
            this.team47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team47.Location = new System.Drawing.Point(1055, 466);
            this.team47.Name = "team47";
            this.team47.Size = new System.Drawing.Size(137, 22);
            this.team47.TabIndex = 0;
            this.team47.Text = "team";
            // 
            // team16
            // 
            this.team16.BackColor = System.Drawing.Color.Transparent;
            this.team16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team16.Location = new System.Drawing.Point(1198, 33);
            this.team16.Name = "team16";
            this.team16.Size = new System.Drawing.Size(137, 22);
            this.team16.TabIndex = 0;
            this.team16.Text = "team";
            // 
            // team24
            // 
            this.team24.BackColor = System.Drawing.Color.Transparent;
            this.team24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team24.Location = new System.Drawing.Point(1198, 284);
            this.team24.Name = "team24";
            this.team24.Size = new System.Drawing.Size(137, 22);
            this.team24.TabIndex = 0;
            this.team24.Text = "team";
            // 
            // team20
            // 
            this.team20.BackColor = System.Drawing.Color.Transparent;
            this.team20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team20.Location = new System.Drawing.Point(1198, 158);
            this.team20.Name = "team20";
            this.team20.Size = new System.Drawing.Size(137, 22);
            this.team20.TabIndex = 0;
            this.team20.Text = "team";
            // 
            // team28
            // 
            this.team28.BackColor = System.Drawing.Color.Transparent;
            this.team28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team28.Location = new System.Drawing.Point(1198, 409);
            this.team28.Name = "team28";
            this.team28.Size = new System.Drawing.Size(137, 22);
            this.team28.TabIndex = 0;
            this.team28.Text = "team";
            // 
            // team17
            // 
            this.team17.BackColor = System.Drawing.Color.Transparent;
            this.team17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team17.Location = new System.Drawing.Point(1198, 60);
            this.team17.Name = "team17";
            this.team17.Size = new System.Drawing.Size(137, 22);
            this.team17.TabIndex = 0;
            this.team17.Text = "team";
            // 
            // team25
            // 
            this.team25.BackColor = System.Drawing.Color.Transparent;
            this.team25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team25.Location = new System.Drawing.Point(1198, 311);
            this.team25.Name = "team25";
            this.team25.Size = new System.Drawing.Size(137, 22);
            this.team25.TabIndex = 0;
            this.team25.Text = "team";
            // 
            // team21
            // 
            this.team21.BackColor = System.Drawing.Color.Transparent;
            this.team21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team21.Location = new System.Drawing.Point(1198, 185);
            this.team21.Name = "team21";
            this.team21.Size = new System.Drawing.Size(137, 22);
            this.team21.TabIndex = 0;
            this.team21.Text = "team";
            // 
            // team29
            // 
            this.team29.BackColor = System.Drawing.Color.Transparent;
            this.team29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team29.Location = new System.Drawing.Point(1198, 436);
            this.team29.Name = "team29";
            this.team29.Size = new System.Drawing.Size(137, 22);
            this.team29.TabIndex = 0;
            this.team29.Text = "team";
            // 
            // team18
            // 
            this.team18.BackColor = System.Drawing.Color.Transparent;
            this.team18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team18.Location = new System.Drawing.Point(1198, 95);
            this.team18.Name = "team18";
            this.team18.Size = new System.Drawing.Size(137, 22);
            this.team18.TabIndex = 0;
            this.team18.Text = "team";
            // 
            // team26
            // 
            this.team26.BackColor = System.Drawing.Color.Transparent;
            this.team26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team26.Location = new System.Drawing.Point(1198, 346);
            this.team26.Name = "team26";
            this.team26.Size = new System.Drawing.Size(137, 22);
            this.team26.TabIndex = 0;
            this.team26.Text = "team";
            // 
            // team22
            // 
            this.team22.BackColor = System.Drawing.Color.Transparent;
            this.team22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team22.Location = new System.Drawing.Point(1198, 220);
            this.team22.Name = "team22";
            this.team22.Size = new System.Drawing.Size(137, 22);
            this.team22.TabIndex = 0;
            this.team22.Text = "team";
            // 
            // team30
            // 
            this.team30.BackColor = System.Drawing.Color.Transparent;
            this.team30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team30.Location = new System.Drawing.Point(1198, 471);
            this.team30.Name = "team30";
            this.team30.Size = new System.Drawing.Size(137, 22);
            this.team30.TabIndex = 0;
            this.team30.Text = "team";
            // 
            // team19
            // 
            this.team19.BackColor = System.Drawing.Color.Transparent;
            this.team19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team19.Location = new System.Drawing.Point(1198, 122);
            this.team19.Name = "team19";
            this.team19.Size = new System.Drawing.Size(137, 22);
            this.team19.TabIndex = 0;
            this.team19.Text = "team";
            // 
            // team27
            // 
            this.team27.BackColor = System.Drawing.Color.Transparent;
            this.team27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team27.Location = new System.Drawing.Point(1198, 373);
            this.team27.Name = "team27";
            this.team27.Size = new System.Drawing.Size(137, 22);
            this.team27.TabIndex = 0;
            this.team27.Text = "team";
            // 
            // team23
            // 
            this.team23.BackColor = System.Drawing.Color.Transparent;
            this.team23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team23.Location = new System.Drawing.Point(1198, 247);
            this.team23.Name = "team23";
            this.team23.Size = new System.Drawing.Size(137, 22);
            this.team23.TabIndex = 0;
            this.team23.Text = "team";
            // 
            // team31
            // 
            this.team31.BackColor = System.Drawing.Color.Transparent;
            this.team31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.team31.Location = new System.Drawing.Point(1198, 498);
            this.team31.Name = "team31";
            this.team31.Size = new System.Drawing.Size(137, 22);
            this.team31.TabIndex = 0;
            this.team31.Text = "team";
            // 
            // playButton
            // 
            this.playButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.playButton.Location = new System.Drawing.Point(636, 328);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(134, 35);
            this.playButton.TabIndex = 1;
            this.playButton.Text = "Play";
            this.playButton.UseVisualStyleBackColor = true;
            this.playButton.Click += new System.EventHandler(this.PlayButton_Click);
            // 
            // result
            // 
            this.result.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.result.ForeColor = System.Drawing.Color.Black;
            this.result.Location = new System.Drawing.Point(442, 120);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(457, 51);
            this.result.TabIndex = 2;
            this.result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(673, 375);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "p - пенальти";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(64, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 16);
            this.label2.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(673, 206);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 16);
            this.label10.TabIndex = 4;
            this.label10.Text = "champion";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1349, 532);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.result);
            this.Controls.Add(this.playButton);
            this.Controls.Add(this.team47);
            this.Controls.Add(this.team39);
            this.Controls.Add(this.team55);
            this.Controls.Add(this.team51);
            this.Controls.Add(this.team45);
            this.Controls.Add(this.team37);
            this.Controls.Add(this.team43);
            this.Controls.Add(this.team35);
            this.Controls.Add(this.team59);
            this.Controls.Add(this.team61);
            this.Controls.Add(this.team57);
            this.Controls.Add(this.team53);
            this.Controls.Add(this.team49);
            this.Controls.Add(this.team41);
            this.Controls.Add(this.team33);
            this.Controls.Add(this.team31);
            this.Controls.Add(this.team15);
            this.Controls.Add(this.team23);
            this.Controls.Add(this.team7);
            this.Controls.Add(this.team46);
            this.Controls.Add(this.team38);
            this.Controls.Add(this.team54);
            this.Controls.Add(this.team50);
            this.Controls.Add(this.team44);
            this.Controls.Add(this.team36);
            this.Controls.Add(this.team58);
            this.Controls.Add(this.team27);
            this.Controls.Add(this.team11);
            this.Controls.Add(this.team60);
            this.Controls.Add(this.team42);
            this.Controls.Add(this.team34);
            this.Controls.Add(this.team56);
            this.Controls.Add(this.team19);
            this.Controls.Add(this.team3);
            this.Controls.Add(this.team52);
            this.Controls.Add(this.team48);
            this.Controls.Add(this.team40);
            this.Controls.Add(this.team32);
            this.Controls.Add(this.team30);
            this.Controls.Add(this.team14);
            this.Controls.Add(this.team22);
            this.Controls.Add(this.team6);
            this.Controls.Add(this.team26);
            this.Controls.Add(this.team10);
            this.Controls.Add(this.team18);
            this.Controls.Add(this.team2);
            this.Controls.Add(this.team29);
            this.Controls.Add(this.team13);
            this.Controls.Add(this.team21);
            this.Controls.Add(this.team5);
            this.Controls.Add(this.team25);
            this.Controls.Add(this.team9);
            this.Controls.Add(this.team17);
            this.Controls.Add(this.team1);
            this.Controls.Add(this.team28);
            this.Controls.Add(this.team12);
            this.Controls.Add(this.team20);
            this.Controls.Add(this.team4);
            this.Controls.Add(this.team24);
            this.Controls.Add(this.team8);
            this.Controls.Add(this.team16);
            this.Controls.Add(this.team0);
            this.MaximumSize = new System.Drawing.Size(1365, 571);
            this.MinimumSize = new System.Drawing.Size(1365, 571);
            this.Name = "Form1";
            this.Text = "Football championship";
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label team0;
		private System.Windows.Forms.Label team1;
		private System.Windows.Forms.Label team2;
		private System.Windows.Forms.Label team3;
		private System.Windows.Forms.Label team4;
		private System.Windows.Forms.Label team5;
		private System.Windows.Forms.Label team6;
		private System.Windows.Forms.Label team7;
		private System.Windows.Forms.Label team8;
		private System.Windows.Forms.Label team12;
		private System.Windows.Forms.Label team9;
		private System.Windows.Forms.Label team13;
		private System.Windows.Forms.Label team10;
		private System.Windows.Forms.Label team14;
		private System.Windows.Forms.Label team11;
		private System.Windows.Forms.Label team15;
		private System.Windows.Forms.Label team32;
		private System.Windows.Forms.Label team33;
		private System.Windows.Forms.Label team34;
		private System.Windows.Forms.Label team35;
		private System.Windows.Forms.Label team36;
		private System.Windows.Forms.Label team37;
		private System.Windows.Forms.Label team38;
		private System.Windows.Forms.Label team39;
		private System.Windows.Forms.Label team48;
		private System.Windows.Forms.Label team49;
		private System.Windows.Forms.Label team50;
		private System.Windows.Forms.Label team51;
		private System.Windows.Forms.Label team56;
		private System.Windows.Forms.Label team57;
		private System.Windows.Forms.Label team60;
		private System.Windows.Forms.Label team61;
		private System.Windows.Forms.Label team58;
		private System.Windows.Forms.Label team59;
		private System.Windows.Forms.Label team52;
		private System.Windows.Forms.Label team54;
		private System.Windows.Forms.Label team53;
		private System.Windows.Forms.Label team55;
		private System.Windows.Forms.Label team40;
		private System.Windows.Forms.Label team42;
		private System.Windows.Forms.Label team44;
		private System.Windows.Forms.Label team46;
		private System.Windows.Forms.Label team41;
		private System.Windows.Forms.Label team43;
		private System.Windows.Forms.Label team45;
		private System.Windows.Forms.Label team47;
		private System.Windows.Forms.Label team16;
		private System.Windows.Forms.Label team24;
		private System.Windows.Forms.Label team20;
		private System.Windows.Forms.Label team28;
		private System.Windows.Forms.Label team17;
		private System.Windows.Forms.Label team25;
		private System.Windows.Forms.Label team21;
		private System.Windows.Forms.Label team29;
		private System.Windows.Forms.Label team18;
		private System.Windows.Forms.Label team26;
		private System.Windows.Forms.Label team22;
		private System.Windows.Forms.Label team30;
		private System.Windows.Forms.Label team19;
		private System.Windows.Forms.Label team27;
		private System.Windows.Forms.Label team23;
		private System.Windows.Forms.Label team31;
		private System.Windows.Forms.Button playButton;
		private System.Windows.Forms.Label result;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label10;
	}
}

