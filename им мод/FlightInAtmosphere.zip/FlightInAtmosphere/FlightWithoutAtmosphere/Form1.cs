﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightWithoutAtmosphere
{
    public partial class Form1 : Form
    {
        private Model model;
        public Form1()
        {
            InitializeComponent();
            model = new Model(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            model.Start();
            chart1.Series[0].Points.Clear();
            GraphDisplay();

            timer1.Start(); 
        }
        private void GraphDisplay ()
        {
            double xMax = model.BalisticMovmentX();
            double yMax = model.BalisticMovmentY();
            chart1.ChartAreas[0].AxisX.Maximum = xMax;
            chart1.ChartAreas[0].AxisY.Maximum = yMax;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            bool flag = model.NewStep();

            labTime.Text = $"Time:{model.GetTime()}s";
            if (flag)
            {
                timer1.Stop();
            }
        }

        public void AddPoint(double x, double y)
        {
            chart1.Series[0].Points.AddXY(x, y);
        }
        public double GetAngle()
        {
            return (double)edAngle.Value;
        }
        public double GetSpeed()
        {
            return (double)edSpeed.Value;
        }
        public double GetHeight()
        {
            return (double)edHeight.Value;
        }
        public double GetWeight()
        {
            return (double)edWeight.Value;
        }
        public double GetSquare()
        {
            return (double)edSquare.Value;
        }
        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void btnResume_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
