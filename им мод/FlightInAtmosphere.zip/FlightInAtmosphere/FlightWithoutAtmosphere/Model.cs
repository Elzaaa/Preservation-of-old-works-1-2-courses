﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightWithoutAtmosphere
{
    public class Model
    {
        public Form1 form;
        public Model(Form1 form)
        {
            this.form = form;
        }
        Object obj = new Object();
        double k, t, vx, vy, x, y;
        public void Start()
        {
            StartValues();
        }
        private void StartValues()
        {
            obj.a = form.GetAngle();
            obj.v0 = form.GetSpeed();
            obj.y0 = form.GetHeight();
            obj.m = form.GetWeight();
            obj.S = form.GetSquare();

            k = 0.5 * Constants.C * obj.S * Constants.rho / obj.m;

            vx = obj.v0 * Math.Cos(obj.a * Math.PI / 180);
            vy = obj.v0 * Math.Sin(obj.a * Math.PI / 180);

            t = 0;
            x = 0;
            y = obj.y0;
        }
        
        public double BalisticMovmentX()
        {
            double xMax = (obj.v0 * obj.v0) / Constants.g * Math.Sin(2 * obj.a * Math.PI / 180);
            return xMax;
        }
        public double BalisticMovmentY()
        {
            double yMax = ((obj.v0 * obj.v0) / (2 * Constants.g)) * Math.Sin(obj.a * Math.PI / 180) * Math.Sin(obj.a * Math.PI / 180);
            return yMax;
        }

        public bool NewStep ()
        {
            if (t == 0)
            {
                form.AddPoint(x, y);
            }
            t += Constants.dt;
            vx = vx - k * vx * Math.Sqrt(vx * vx + vy * vy) * Constants.dt;
            vy = vy - (Constants.g + k * vy * Math.Sqrt(vx * vx + vy * vy)) * Constants.dt;

            x = x + vx * Constants.dt;
            y = y + vy * Constants.dt;

            form.AddPoint(x, y);
            if (y <= 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        double FlightTime;
        public double GetTime()
        {
            FlightTime = (double) t / 100;
            return FlightTime;
        }

        public class Object
        {
            public double a, v0, y0, m, S;
        }
        public class Constants
        {
            public const double g = 9.81;
            public const double rho = 1.29;
            public const double C = 0.15;
            public const double dt = 0.01;
        }
    }
}
