﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trains
{
    public partial class Form1 : Form
    {
        Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(month, score);
            comboBox1.SelectedItem = "Осень";
            comboBox2.SelectedItem = "Стабильная";
        }

        double startSalary = 35000; //средняя зарплата сотрудника
        double averageTicketPrice = 4500;
        double DissmissalRate = 0.05; //5% максимум увольнений за месяц


        double score = 1000000000;
        double ticketPrice;
        double fuelPrice; //единица дизеля в час
        double salary = 35000; //средняя зарплата сотрудника
        int staffAmount = 300; //текущее количество персонала - изгачально 300, на 20 поездов
        int staffAmountForOneTrain = 15; //требуется человек на один поезд (итого 15*20  = 300 на 20 поездов)
        //int maximumTrainAmount = 20;
        int trainAmount = 20;        
        
        int month = 0;

        //int value = rnd.Next(0, 10);
        /*double kilometrs = 6000; //100 часов на проезд поезда, один поезд около 4-5 дней идет
        double speed = 60;*/
        private void btStart_Click(object sender, EventArgs e)
        {
            if (!timer.Enabled)
                timer.Start();
            fuelPrice = (double)numericUpDown1.Value;

        }

        private void timer_Tick(object sender, EventArgs e)
        {
            month += 1;
            score = score + MoneyIncome() - MoneyLoss();
            labelScore.Text = $"{score}";
            chart1.Series[0].Points.AddXY(month, score);
            staffChange();
            trainsNumberNextMonth();
        }

        private void btStop_Click(object sender, EventArgs e)
        {
            if (timer.Enabled)
                timer.Stop();
        }

        private double MoneyIncome()
        {
            int allTicketMonth = 500 * 4; // в поезде 500 мест на неделю. Итого 4 раз по 7 суток в месяц
            double result = 0;
            int ticketsSold;
            for(int i = 0; i < trainAmount; i++)
            {
                var k = ticketPrice / averageTicketPrice;
                var newFree = allTicketMonth * 0.4 * k; //мест свободных при стандартных 40%
                int freePlaces = (int)newFree;

                if (freePlaces > allTicketMonth)
                    freePlaces = allTicketMonth;
                else
                {
                    if (freePlaces < 0)
                        freePlaces = 0;
                }
                freePlaces = rand.Next(freePlaces/2, freePlaces);
                ticketsSold = allTicketMonth - freePlaces;//50 мест в вагоне, 10 вагонов = 500 мест 

                //ticketsSold = allTicketMonth;
                result += ticketsSold * ticketPrice;
            }
            return result;
        } 

        private double MoneyLoss()
        {
            double result = 0;
            //топливо 800 л/сутки, 30 дней в месяце
            result += 800 * trainAmount * 30 * fuelPrice;
            result += staffAmount * salary;
            return result;
        }

        private void staffChange()
        {
            //уволилось человек
            var less = rand.Next(0, (int)(staffAmount * DissmissalRate));
            var more = rand.Next(0, 20);
            staffAmount = staffAmount - less + more;
            if (staffAmount < 0)
                staffAmount = 0;
        }

        private void trainsNumberNextMonth()
        {
            trainAmount = staffAmount / staffAmountForOneTrain;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*string season = comboBox1.Text;
            switch (season)
            {
                case "Осень":
                case "Весна":


                    break;
                case "Зима":

                    break;

                case "Лето":
                    break;
            }*/
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            fuelPrice = (double)numericUpDown1.Value;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string economy = comboBox2.Text;
            switch (economy)
            {
                case "Нестабильное":
                    ticketPrice = rand.Next(2000, 7000);
                    salary = 25000;
                    DissmissalRate = 0.5;
                    break;
                case "Стабильная":
                    ticketPrice = 4500;
                    salary = 35000;
                    DissmissalRate = 0.4;
                    break;

                case "Улучшающаяся":
                    ticketPrice = 5500;
                    salary = 45000;
                    DissmissalRate = 0.05;
                    break;
            }
        }


    }
}
