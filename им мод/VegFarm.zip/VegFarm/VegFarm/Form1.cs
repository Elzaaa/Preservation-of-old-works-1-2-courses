﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VegFarm
{
       
    public partial class Form1 : Form
    {

        Dictionary<CheckBox, Cell> field = new Dictionary<CheckBox, Cell>();
        private int day = 0;
        private Cash _cash;
        public Form1()
        {
            _cash = new Cash(100);
            InitializeComponent();

            foreach (CheckBox cb in tableLayoutPanel1.Controls)
            {
                field[cb] = new Cell(_cash);
            }

        }
 
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox cb = (sender as CheckBox);
            if (cb.Checked) Plant(cb);
            else Harvest(cb);
        }
        private void Plant (CheckBox cb)
        {
            //cb.BackColor = Color.Black;
            field[cb].Plant();
            UpdateBox(cb);
        }
        private void Harvest(CheckBox cb)
        {
            //cb.BackColor = Color.White;
            field[cb].Harvest();
            UpdateBox(cb);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            foreach (CheckBox cb in tableLayoutPanel1.Controls)
            {
                NextStep(cb);
            }
            day++;
            LabDay.Text = "Day:" + day;
            labSpeed.Text = "Choose your speed:" + _currentSpeed + "x";
            labCash.Text = "Cash:" + _cash.Amount;
        }
        private void NextStep (CheckBox cb)
        {
            field[cb].NextStep();
            UpdateBox(cb);
        }
        private void UpdateBox(CheckBox cb)
        {
            Color c = Color.White;
            switch (field[cb].state)
            {
                case CellState.Planted:
                    c = Color.Black;
                    break;
                case CellState.Green:
                    c = Color.Green;
                    break;
                case CellState.Immature:
                    c = Color.Yellow;
                    break;
                case CellState.Mature:
                    c = Color.Red;
                    break;
                case CellState.Overgrow:
                    c = Color.Brown;
                    break;
            }
            cb.BackColor = c;
        }
        private int _currentSpeed = 1;
        private void btnFast_Click(object sender, EventArgs e)
        {
            _currentSpeed = Math.Min(_currentSpeed + 1, 10);
            labSpeed.Text = "Choose your speed:" + _currentSpeed + "x";
            timer1.Interval = 100 / _currentSpeed;
        }

        private void btnLow_Click(object sender, EventArgs e)
        {
            _currentSpeed = Math.Max(_currentSpeed - 1, 1);
            labSpeed.Text = "Choose your speed:" + _currentSpeed + "x";
            timer1.Interval = 100 / _currentSpeed;
        }
    }
    public class Cash
    {
        public int Amount { get;  set; }
        public Cash(int initialAmount) { Amount = initialAmount; }
    }
    enum CellState
    {
        Empty,
        Planted,
        Green,
        Immature,
        Mature,
        Overgrow
    }
    class Cell
    {
        public CellState state = CellState.Empty;

        private int progress = 0;
        const int prPlanted = 20;
        const int prGreen = 80;
        const int prImmature = 100;
        const int prMature = 120;

        private Cash Cash { get; set; }
        public Cell(Cash cash) { Cash = cash; }
        public void Plant()
        {
            state++;
            Cash.Amount -= 2;
        }
        public void Harvest()
        {
            if (state == CellState.Planted) Cash.Amount += 0;
            else if (state == CellState.Green) Cash.Amount += 0;
            else if (state == CellState.Immature) Cash.Amount += 3;
            else if (state == CellState.Mature) Cash.Amount += 5;
            else if (state == CellState.Overgrow) Cash.Amount -= 1;
            state = CellState.Empty;
            progress = 0;
        }
        public void NextStep()
        {
            if ((state != CellState.Empty) && (state != CellState.Overgrow))
            {
                progress++;
                if (progress == 1) state = CellState.Planted;
                else if(progress == prPlanted) state = CellState.Green;
                else if (progress == prGreen) state = CellState.Immature;
                else if (progress == prImmature) state = CellState.Mature;
                else if (progress == prMature) state = CellState.Overgrow;
            }
        }

    }
}
