﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CurRate
{
    public partial class Form1 : Form
    {
        private Cash _cash;
        private Cash _cashDollars;
        public Form1()
        {
            _cash = new Cash(100);
            _cashDollars = new Cash(0);
            InitializeComponent();
            UpdateLab();

        }

        int days = 0;
        private void btCalculate_Click(object sender, EventArgs e)
        {
            labMesage.Text = " ";

            const double k = 0.02;
            Random random = new Random();
            double rate = (double)edRate.Value;

            days++;
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(0, rate);

            rate = rate * (1 + k * (random.NextDouble() - 0.5));
            chart1.Series[0].Points.AddXY(days, rate);

            UpdateLab();
        }

        private void UpdateLab()
        {
            labСash.Text = "Cash:" + _cash.Amount;
            labDollars.Text = "Dollars:" + _cashDollars.Amount;
        }
        private void EndGame()
        {
            labEnd.Text = "You lose lasted " + days + " days";
        }
        public void MessageBuy()
        {
            labMesage.Text = "You do not have enough funds, but you can buy less!";
        }
        public void MessageSell()
        {
            labMesage.Text = "You don't have that much";
        }
 
        private void btnBuy_Click(object sender, EventArgs e)
        {
            labMesage.Text = " ";
            if (numBuy.Value <= 0)
            {
                UpdateLab();
            }
            else if (_cash.Amount > (decimal)edRate.Value * numBuy.Value)
            {
                _cashDollars.Amount += numBuy.Value;
                _cash.Amount -= (decimal)edRate.Value;
                UpdateLab();
            }
            else
            {
                if (_cash.Amount < (decimal)edRate.Value * numBuy.Value && _cash.Amount > (decimal)edRate.Value - 10)
                {
                    MessageBuy();
                }

                else
                {
                    EndGame();
                }
            }
        }

        private void btnSellDollars_Click(object sender, EventArgs e)
        {
            if (_cashDollars.Amount > 0)
            {
                _cashDollars.Amount -= numSell.Value;
                _cash.Amount += (decimal)edRate.Value;
                UpdateLab();
            }
            else if (_cashDollars.Amount < numSell.Value)
            {
                MessageSell();
            }
        }
        public class Cash
        {
            public decimal Amount { get; set; }
            public Cash(decimal initialAmount) { Amount = initialAmount; }
        }

    }
}
