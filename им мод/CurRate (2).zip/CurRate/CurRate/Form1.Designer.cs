﻿namespace CurRate
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labEnd = new System.Windows.Forms.Label();
            this.numSell = new System.Windows.Forms.NumericUpDown();
            this.numBuy = new System.Windows.Forms.NumericUpDown();
            this.btnSellDollars = new System.Windows.Forms.Button();
            this.btnBuy = new System.Windows.Forms.Button();
            this.labDollars = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnNextDay = new System.Windows.Forms.Button();
            this.labСash = new System.Windows.Forms.Label();
            this.edRate = new System.Windows.Forms.NumericUpDown();
            this.labCurrentCourse = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.labMesage = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSell)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBuy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.labMesage);
            this.panel1.Controls.Add(this.labEnd);
            this.panel1.Controls.Add(this.numSell);
            this.panel1.Controls.Add(this.numBuy);
            this.panel1.Controls.Add(this.btnSellDollars);
            this.panel1.Controls.Add(this.btnBuy);
            this.panel1.Controls.Add(this.labDollars);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnNextDay);
            this.panel1.Controls.Add(this.labСash);
            this.panel1.Controls.Add(this.edRate);
            this.panel1.Controls.Add(this.labCurrentCourse);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 100);
            this.panel1.TabIndex = 0;
            // 
            // labEnd
            // 
            this.labEnd.AutoSize = true;
            this.labEnd.Location = new System.Drawing.Point(579, 46);
            this.labEnd.Name = "labEnd";
            this.labEnd.Size = new System.Drawing.Size(0, 13);
            this.labEnd.TabIndex = 13;
            // 
            // numSell
            // 
            this.numSell.Location = new System.Drawing.Point(323, 44);
            this.numSell.Name = "numSell";
            this.numSell.Size = new System.Drawing.Size(85, 20);
            this.numSell.TabIndex = 12;
            // 
            // numBuy
            // 
            this.numBuy.Location = new System.Drawing.Point(323, 18);
            this.numBuy.Name = "numBuy";
            this.numBuy.Size = new System.Drawing.Size(85, 20);
            this.numBuy.TabIndex = 11;
            // 
            // btnSellDollars
            // 
            this.btnSellDollars.Location = new System.Drawing.Point(242, 44);
            this.btnSellDollars.Name = "btnSellDollars";
            this.btnSellDollars.Size = new System.Drawing.Size(75, 23);
            this.btnSellDollars.TabIndex = 8;
            this.btnSellDollars.Text = "Sell Dollars";
            this.btnSellDollars.UseVisualStyleBackColor = true;
            this.btnSellDollars.Click += new System.EventHandler(this.btnSellDollars_Click);
            // 
            // btnBuy
            // 
            this.btnBuy.Location = new System.Drawing.Point(242, 15);
            this.btnBuy.Name = "btnBuy";
            this.btnBuy.Size = new System.Drawing.Size(75, 23);
            this.btnBuy.TabIndex = 7;
            this.btnBuy.Text = "Buy Dollars";
            this.btnBuy.UseVisualStyleBackColor = true;
            this.btnBuy.Click += new System.EventHandler(this.btnBuy_Click);
            // 
            // labDollars
            // 
            this.labDollars.AutoSize = true;
            this.labDollars.Location = new System.Drawing.Point(134, 68);
            this.labDollars.Name = "labDollars";
            this.labDollars.Size = new System.Drawing.Size(39, 13);
            this.labDollars.TabIndex = 6;
            this.labDollars.Text = "Dollars";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 5;
            // 
            // btnNextDay
            // 
            this.btnNextDay.Location = new System.Drawing.Point(436, 15);
            this.btnNextDay.Name = "btnNextDay";
            this.btnNextDay.Size = new System.Drawing.Size(82, 30);
            this.btnNextDay.TabIndex = 4;
            this.btnNextDay.Text = "Next Day";
            this.btnNextDay.UseVisualStyleBackColor = true;
            this.btnNextDay.Click += new System.EventHandler(this.btCalculate_Click);
            // 
            // labСash
            // 
            this.labСash.AutoSize = true;
            this.labСash.Location = new System.Drawing.Point(33, 68);
            this.labСash.Name = "labСash";
            this.labСash.Size = new System.Drawing.Size(40, 13);
            this.labСash.TabIndex = 2;
            this.labСash.Text = "Rubles";
            // 
            // edRate
            // 
            this.edRate.DecimalPlaces = 2;
            this.edRate.Location = new System.Drawing.Point(127, 18);
            this.edRate.Name = "edRate";
            this.edRate.Size = new System.Drawing.Size(97, 20);
            this.edRate.TabIndex = 1;
            this.edRate.Value = new decimal(new int[] {
            8953,
            0,
            0,
            131072});
            // 
            // labCurrentCourse
            // 
            this.labCurrentCourse.AutoSize = true;
            this.labCurrentCourse.Location = new System.Drawing.Point(33, 20);
            this.labCurrentCourse.Name = "labCurrentCourse";
            this.labCurrentCourse.Size = new System.Drawing.Size(76, 13);
            this.labCurrentCourse.TabIndex = 0;
            this.labCurrentCourse.Text = "Current course";
            // 
            // chart1
            // 
            chartArea2.AxisX.Minimum = 0D;
            chartArea2.AxisY.Minimum = 50D;
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart1.Location = new System.Drawing.Point(0, 100);
            this.chart1.Name = "chart1";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.IsValueShownAsLabel = true;
            series2.LabelFormat = "f2";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(758, 350);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // labMesage
            // 
            this.labMesage.AutoSize = true;
            this.labMesage.Location = new System.Drawing.Point(419, 68);
            this.labMesage.Name = "labMesage";
            this.labMesage.Size = new System.Drawing.Size(0, 13);
            this.labMesage.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 450);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSell)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBuy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnNextDay;
        private System.Windows.Forms.Label labСash;
        private System.Windows.Forms.NumericUpDown edRate;
        private System.Windows.Forms.Label labCurrentCourse;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labDollars;
        private System.Windows.Forms.Button btnBuy;
        private System.Windows.Forms.NumericUpDown numSell;
        private System.Windows.Forms.NumericUpDown numBuy;
        private System.Windows.Forms.Button btnSellDollars;
        private System.Windows.Forms.Label labEnd;
        private System.Windows.Forms.Label labMesage;
    }
}

