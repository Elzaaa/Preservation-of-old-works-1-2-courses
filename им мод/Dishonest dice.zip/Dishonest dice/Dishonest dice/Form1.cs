﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dishonest_dice
{
    public partial class Form1 : Form
    {

        int attempt = 0;

        public Form1()
        {
            InitializeComponent();
        }

        Dice dice = new Dice();
        CheatDice cheatDice = new CheatDice();
        int dice1;
        int diceEn1;
        int sumPoints, sumEnPoints;

        private void button1_Click(object sender, EventArgs e)
        {
            dice1 = dice.roll();
            diceEn1 = cheatDice.roll();
            
            label4.Text = dice1.ToString();
            label6.Text = diceEn1.ToString();

            if (attempt < 3)
            {
                attempt++;
                labAttempt.Text = "Attempt:" + attempt + " / 3";
                sumPoints += dice1;
                sumEnPoints += diceEn1;
                label1.Text = "Your summ " + sumPoints;
                label2.Text = "Enemy summ " + sumEnPoints;
            }
            else
            {
                if (sumPoints > sumEnPoints)
                {
                    label3.Text = "You win!";
                }
                else
                {
                    label3.Text = "Enemy win!";
                }
            }

        }
    }

}
public class RandomDice
{
    Random rnd = new Random();
    public double next()
    {
        return rnd.NextDouble();
    }

    private double NextDouble()
    {
        throw new NotImplementedException();
    }
}
public class Dice
{
    RandomDice baseGen = new RandomDice();
    double number;
    public int roll()
    {
        number = baseGen.next();
        int k = 0;
        while (number > 0)
        {
            number -= 0.06;
            k++;
        }
        return k;
    }
}

public class CheatDice
{
    RandomDice baseGen = new RandomDice();
    double number;
    public int roll()
    {
        number = baseGen.next();
        int k = 0;
        while (number > 0)
        {
            if ((k < 18))  
                number -= 0.04;
            else number -= 0.14;
            k++;
        }
        return k;
    }
}

