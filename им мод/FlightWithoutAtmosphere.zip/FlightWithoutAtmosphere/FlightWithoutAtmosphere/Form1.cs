﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightWithoutAtmosphere
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           // timer1.Interval = 1000;//это твой интервал 1000 милисек = 1секунд
           // timer1.Elapsed += new System.Timers.ElapsedEventHandler(timer1_Tick);//тут подписываемся на событие Start_Game(и каждую секунду будет отрабатывать наше событие в нем уже и твори то угодно)
        }
        double a;
        double v0;
        double y0;

        double t;
        double x;
        double y;
        const double dt = 0.01;
        const double g = 9.81;
        double FlightTime;

        public int counter = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            a = (double)edAngle.Value;
            v0 = (double)edSpeed.Value;
            y0 = (double)edHeight.Value;

            t = 0;
            x = 0;
            y = y0;
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(x, y);

            //Ballistic movement https://planetcalc.ru/1508/
            double xMax = (v0 * v0) / g * Math.Sin(2 * a * Math.PI / 180);
            double yMax = ((v0 * v0) / (2 * g)) * Math.Sin( a * Math.PI / 180) * Math.Sin(a * Math.PI / 180);

            labRangeOfFlight.Text = $"Range of flight:" + xMax;
            labMaximumFlightAltitude.Text = $"Maximum flight altitude:" + yMax;

            chart1.ChartAreas[0].AxisX.Maximum = xMax;
            chart1.ChartAreas[0].AxisY.Maximum = yMax;

            counter = 0;
            timer1.Start();
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            FlightTime = (double) counter / 100;
            counter++;
            labTime.Text = $"Time:" + FlightTime + $"s";
            t += dt;
            x = v0 * Math.Cos(a * Math.PI / 180) * t;
            y = y0 + v0 * Math.Sin(a * Math.PI / 180) * t - g * t * t / 2;
            chart1.Series[0].Points.AddXY(x, y);
            if (y <= 0)
            {
                timer1.Stop();
                counter = 0;
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void btnResume_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

    }
}
