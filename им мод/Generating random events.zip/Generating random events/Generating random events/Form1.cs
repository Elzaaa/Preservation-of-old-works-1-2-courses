﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Generating_random_events
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        int rand;

        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            rand = random.Next(0,11);

            if (rand < 6)
            {
                labelAnswer1.Text = "NO";
            }
            else
            {
                labelAnswer1.Text = "YES";
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            rand = random.Next(0, 11);
            string word = "";

            switch (rand)
            {
                case 1:
                    word = "You are amazing!";
                    break;
                case 2:
                    word = "Everything will be fine";
                    break;
                case 3:
                    word = "Better prepare for the exam";
                    break;
                case 4:
                    word = "Not to do that.";
                    break;
                case 5:
                    word = "Greetings!";
                    break;
                case 6:
                    word = "Better prepare for the exam";
                    break;
                case 7:
                    word = "Yes, a new resident came out";
                    break;
                case 8:
                    word = "Be risky";
                    break;
                case 9:
                    word = "Maybe";
                    break;
                case 10:
                    word = "I do not think so";
                    break;
            }
            labelAnswer1.Text = word;
        }

    }
}